select distinct name from people
join stars on people.id = stars.person_id
where stars.movie_id in
(select stars.movie_id from stars where stars.person_id in
(select people.id from people
where people.name = 'Kevin Bacon' and people.birth = 1958) group by stars.movie_id)
and people.name != 'Kevin Bacon'