select name from directors left join ratings on directors.movie_id = ratings.movie_id
join people on people.id = directors.person_id where ratings.rating >= 9.0 group by directors.person_id