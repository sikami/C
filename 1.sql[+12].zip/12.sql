select movies.title from stars
join people on people.id = stars.person_id
join movies on movies.id = stars.movie_id
where
(stars.person_id in
    (select people.id from people where people.name = 'Johnny Depp')
)
or
(stars.person_id in
    (select people.id from people where people.name = 'Helena Bonham Carter')
)
group by movie_id having count(movie_id) > 1