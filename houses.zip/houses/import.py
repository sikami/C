import csv
import sqlite3
from sys import argv

length = len(argv)
if length != 2:
    exit('Unknown File')

file_name = argv[1].split('.')

if file_name[1] != 'csv':
    exit('Unknown File')
else:
    document = argv[1]

db = sqlite3.connect('students.db')
s = dict()
with open(document, 'r') as file:
    for row in file:
        if row == 'name,house,birth\n':
            continue

        new_row = row.split(',')
        names = new_row[0].split()
        s['house'] = new_row[1]
        _birth = new_row[2].split('\n')
        s['birth'] = _birth[0]
        s['first_name'] = names[0]
        s['middle_name'] = names[1]

        if len(names) > 2:
            s['last_name'] = names[2]
            db.execute('INSERT INTO students (first, middle,last,house,birth) VALUES (?, ?, ?, ?, ?)', (s['first_name'], s['middle_name'], s['last_name'], s['house'], s['birth']))
        else:
            s['last_name'] = s['middle_name']
            db.execute('INSERT INTO students (first,last,house,birth) VALUES (?, ?, ?, ?)', (s['first_name'], s['middle_name'], s['house'], s['birth']))
db.commit()
db.close()