import sqlite3
from sys import argv

houses = ['Slytherin', 'Gryffindor', 'Hufflepuff', 'Ravenclaw']
if len(argv) != 2 or argv[1] not in houses:
    exit('Wrong house name')

house_name = argv[1]
db = sqlite3.connect('students.db')
cur = db.cursor()

cur.execute('SELECT *  from students WHERE house = ? ORDER BY last', (house_name,))
row = cur.fetchall()
for i in row:
    if i[2] == None:
        print ('{} {}, born {}'.format(i[1],i[3],i[5]))
    else:
        print ('{} {} {}, born {}'.format(i[1], i[2], i[3], i[5]))

db.close()