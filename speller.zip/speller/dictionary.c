// Implements a dictionary's functionality

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>

#include "dictionary.h"

#define SIZE 500
// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;

}
node;

struct node *insert(node *start, int slot, node *hashtable[slot], node *list);
struct node *create(const char *letters);

// Number of buckets in hash table
//const unsigned int N = 5000;

// Hash table
node *table[SIZE];
node *head;
node *new;
int count = 0;

// Returns true if word is in dictionary else false
bool check(const char *word)
{
    // TODO
    int index = hash(word);
    node *entry = table[index];

    if (table[index] != NULL)
    {
        while (entry != NULL)
        {
            if (strcasecmp(word, entry->word) == 0)
            {
                return true;
            }
            entry = entry->next;
        }

    }

    return false;
}

// Hashes word to a number
unsigned int hash(const char *word)
{
    int total = 0;

    for (int i = 0; tolower(word[i]) != '\0'; i++)
    {
        total += tolower(word[i]);
    }
    return total % SIZE;

}

// Loads dictionary into memory, returning true if successful else false
bool load(const char *dictionary)
{
    //set all hashtable to null
    for (int i = 0; i < SIZE; i++)
    {
        table[i] = NULL;
    }

    char words[40];
    FILE *fp = fopen(dictionary, "r");
    if (fp == NULL)
    {
        exit(1);
    }
    else
    {
        while (fscanf(fp, "%s", words) != EOF)
        {
            int index = hash(words);
            int *counter = &count;
            *counter += 1;

            if (table[index] == NULL)
            {
                head = create(words);
                table[index] = head;
            }
            else
            {
                new = create(words);
                head = insert(head, index, table, new);
                table[index] = head;

            }
        }

        return true;

    }
    return false;
    fclose(fp);
}

// Returns number of words in dictionary if loaded else 0 if not yet loaded
unsigned int size(void)
{
    // return the number of dictionary
    return count;
}

// Unloads dictionary from memory, returning true if successful else false
bool unload(void)
{
    node *first, *temp, *cursor;
    //iterate throught the hastable


    for (int i = 0; i < SIZE; i++)
    {
        first = table[i];
        cursor = first;
        temp = first;

        while (cursor != NULL)
        {
            cursor = cursor->next;
            free(temp);
            temp = temp->next;

        }
    }

    return true;

}


struct node *create(const char *letters)
{
    node *n = malloc(sizeof(node));
    if (n == NULL)
    {
        exit(1);
    }

    strcpy(n->word, letters);
    n->next = NULL;

    return n;
}

struct node *insert(node *start, int slot, node *hashtable[slot], node *list)
{
    list->next = start;
    hashtable[slot] = list;
    start = list;

    return start;
}



